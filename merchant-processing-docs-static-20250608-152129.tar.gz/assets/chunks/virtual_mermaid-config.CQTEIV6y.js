const e={securityLevel:"loose",startOnLoad:!1,theme:"default"};export{e as default};
