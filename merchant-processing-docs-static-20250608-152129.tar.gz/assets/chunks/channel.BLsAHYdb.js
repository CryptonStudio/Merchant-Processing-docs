import{U as a,C as n}from"../app.CU57W1L2.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
