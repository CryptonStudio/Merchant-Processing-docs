import{_ as r,c as a,o as t,a0 as n}from"./chunks/framework.DCEeW4XT.js";const u=JSON.parse('{"title":"错误处理示例","description":"","frontmatter":{},"headers":[],"relativePath":"zh/examples/error-handling.md","filePath":"zh/examples/error-handling.md"}'),s={name:"zh/examples/error-handling.md"};function o(i,e,l,c,d,p){return t(),a("div",null,e[0]||(e[0]=[n(`<h1 id="错误处理示例" tabindex="-1">错误处理示例 <a class="header-anchor" href="#错误处理示例" aria-label="Permalink to &quot;错误处理示例&quot;">​</a></h1><p>本指南演示了加密货币支付网关的综合错误处理策略，涵盖常见场景和最佳实践。</p><h2 id="概述" tabindex="-1">概述 <a class="header-anchor" href="#概述" aria-label="Permalink to &quot;概述&quot;">​</a></h2><p>正确的错误处理对于加密货币支付系统至关重要，因为：</p><ul><li>网络波动和交易延迟</li><li>地址验证要求</li><li>余额和确认依赖性</li><li>速率限制和 API 约束</li><li>Webhook 交付失败</li></ul><h2 id="错误类型和处理" tabindex="-1">错误类型和处理 <a class="header-anchor" href="#错误类型和处理" aria-label="Permalink to &quot;错误类型和处理&quot;">​</a></h2><h3 id="_1-api-错误处理" tabindex="-1">1. API 错误处理 <a class="header-anchor" href="#_1-api-错误处理" aria-label="Permalink to &quot;1. API 错误处理&quot;">​</a></h3><p>&#39;&#39;&#39;javascript // utils/errorHandler.js class GatewayError extends Error { constructor(code, message, details = {}, statusCode = 500) { super(message); this.name = &#39;GatewayError&#39;; this.code = code; this.details = details; this.statusCode = statusCode; this.timestamp = new Date().toISOString(); } }</p><p>class ErrorHandler { static handleApiError(error, context = {}) { console.error(&#39;API 错误:&#39;, { error: error.message, code: error.code, context, timestamp: new Date().toISOString() });</p><pre><code>// 映射常见 API 错误
switch (error.code) {
  case &#39;INSUFFICIENT_BALANCE&#39;:
    return new GatewayError(
      &#39;INSUFFICIENT_BALANCE&#39;,
      &#39;余额不足，无法执行此操作&#39;,
      { 
        available: error.details?.available,
        required: error.details?.required,
        coin: error.details?.coin
      },
      400
    );

  case &#39;INVALID_ADDRESS&#39;:
    return new GatewayError(
      &#39;INVALID_ADDRESS&#39;,
      &#39;提供的地址无效&#39;,
      { 
        address: error.details?.address,
        network: error.details?.network
      },
      400
    );

  case &#39;RATE_LIMIT_EXCEEDED&#39;:
    return new GatewayError(
      &#39;RATE_LIMIT_EXCEEDED&#39;,
      &#39;超出 API 速率限制&#39;,
      { 
        limit: error.details?.limit,
        resetAt: error.details?.resetAt
      },
      429
    );

  default:
    return new GatewayError(
      &#39;UNKNOWN_ERROR&#39;,
      error.message || &#39;发生未知错误&#39;,
      error.details || {},
      500
    );
}
</code></pre><p>}</p><p>static async withRetry(operation, maxRetries = 3, delay = 1000) { let lastError;</p><pre><code>for (let attempt = 1; attempt &lt;= maxRetries; attempt++) {
  try {
    return await operation();
  } catch (error) {
    lastError = error;
    
    if (attempt === maxRetries) {
      throw new GatewayError(
        &#39;MAX_RETRIES_EXCEEDED&#39;,
        &#39;操作在 &#39; + maxRetries + &#39; 次尝试后失败&#39;,
        { originalError: error.message, attempts: maxRetries }
      );
    }
    
    // 指数退避
    const waitTime = delay * Math.pow(2, attempt - 1);
    console.log(&#39;尝试 &#39; + attempt + &#39; 失败，&#39; + waitTime + &#39;ms 后重试...&#39;);
    await new Promise(resolve =&gt; setTimeout(resolve, waitTime));
  }
}
</code></pre><p>} }</p><p>module.exports = { GatewayError, ErrorHandler }; &#39;&#39;&#39;</p><h3 id="_2-交易错误处理" tabindex="-1">2. 交易错误处理 <a class="header-anchor" href="#_2-交易错误处理" aria-label="Permalink to &quot;2. 交易错误处理&quot;">​</a></h3><p>&#39;&#39;&#39;javascript // services/TransactionErrorHandler.js const { Gateway } = require(&#39;@gateway/crypto-payment-sdk&#39;); const { ErrorHandler, GatewayError } = require(&#39;../utils/errorHandler&#39;);</p><p>class TransactionErrorHandler { constructor() { this.gateway = new Gateway({ apiKey: process.env.GATEWAY_API_KEY, environment: process.env.NODE_ENV === &#39;production&#39; ? &#39;production&#39; : &#39;test&#39; }); }</p><p>async handleTransactionErrors(transactionId, context = {}) { try { const transaction = await ErrorHandler.withRetry(async () =&gt; { return await this.gateway.transactions.get(transactionId); });</p><pre><code>  return this.analyzeTransactionStatus(transaction.data, context);
} catch (error) {
  return this.handleTransactionRetrievalError(error, transactionId, context);
}
</code></pre><p>}</p><p>analyzeTransactionStatus(transaction, context) { const analysis = { transactionId: transaction.id, status: transaction.status, issues: [], recommendations: [], severity: &#39;info&#39; };</p><pre><code>switch (transaction.status) {
  case &#39;failed&#39;:
    analysis.issues.push(&#39;交易在区块链上失败&#39;);
    analysis.recommendations.push(&#39;在区块链浏览器中检查交易哈希&#39;);
    analysis.severity = &#39;error&#39;;
    break;

  case &#39;pending&#39;:
    const pendingTime = Date.now() - new Date(transaction.created_at).getTime();
    const maxPendingTime = 30 * 60 * 1000; // 30 分钟
    
    if (pendingTime &gt; maxPendingTime) {
      analysis.issues.push(&#39;交易待处理时间过长&#39;);
      analysis.recommendations.push(&#39;检查网络拥堵状况&#39;);
      analysis.severity = &#39;warning&#39;;
    }
    break;

  case &#39;confirmed&#39;:
    analysis.recommendations.push(&#39;交易已成功确认&#39;);
    break;

  default:
    analysis.issues.push(&#39;未知交易状态: &#39; + transaction.status + &#39;&#39;);
    analysis.severity = &#39;warning&#39;;
}

return analysis;
</code></pre><p>} }</p><p>module.exports = TransactionErrorHandler; &#39;&#39;&#39;</p><h2 id="最佳实践" tabindex="-1">最佳实践 <a class="header-anchor" href="#最佳实践" aria-label="Permalink to &quot;最佳实践&quot;">​</a></h2><h3 id="_1-结构化日志记录" tabindex="-1">1. 结构化日志记录 <a class="header-anchor" href="#_1-结构化日志记录" aria-label="Permalink to &quot;1. 结构化日志记录&quot;">​</a></h3><p>&#39;&#39;&#39;javascript // utils/logger.js const winston = require(&#39;winston&#39;);</p><p>const logger = winston.createLogger({ level: &#39;info&#39;, format: winston.format.combine( winston.format.timestamp(), winston.format.errors({ stack: true }), winston.format.json() ), transports: [ new winston.transports.File({ filename: &#39;error.log&#39;, level: &#39;error&#39; }), new winston.transports.Console() ] });</p><p>module.exports = logger; &#39;&#39;&#39;</p><h3 id="_2-用户友好的错误消息" tabindex="-1">2. 用户友好的错误消息 <a class="header-anchor" href="#_2-用户友好的错误消息" aria-label="Permalink to &quot;2. 用户友好的错误消息&quot;">​</a></h3><p>&#39;&#39;&#39;javascript // utils/userMessages.js const userMessages = { &#39;INSUFFICIENT_BALANCE&#39;: &#39;余额不足，无法执行此操作&#39;, &#39;INVALID_ADDRESS&#39;: &#39;请检查地址是否正确&#39;, &#39;RATE_LIMIT_EXCEEDED&#39;: &#39;请求过多，请稍后再试&#39;, &#39;NETWORK_ERROR&#39;: &#39;网络问题，请稍后再试&#39;, &#39;TRANSACTION_NOT_FOUND&#39;: &#39;未找到交易&#39; };</p><p>function getUserMessage(errorCode) { return userMessages[errorCode] || &#39;发生错误，请稍后再试&#39;; }</p><p>module.exports = { getUserMessage }; &#39;&#39;&#39;</p><h3 id="_3-集中式错误处理-express" tabindex="-1">3. 集中式错误处理 Express <a class="header-anchor" href="#_3-集中式错误处理-express" aria-label="Permalink to &quot;3. 集中式错误处理 Express&quot;">​</a></h3><p>&#39;&#39;&#39;javascript // middleware/errorMiddleware.js const { GatewayError } = require(&#39;../utils/errorHandler&#39;);</p><p>function errorMiddleware(error, req, res, next) { console.error(&#39;发生错误:&#39;, { error: error.message, url: req.url, method: req.method, timestamp: new Date().toISOString() });</p><p>if (error instanceof GatewayError) { return res.status(error.statusCode).json({ success: false, error: { code: error.code, message: error.message, details: error.details, timestamp: error.timestamp } }); }</p><p>res.status(500).json({ success: false, error: { code: &#39;INTERNAL_SERVER_ERROR&#39;, message: &#39;内部服务器错误&#39;, timestamp: new Date().toISOString() } }); }</p><p>module.exports = errorMiddleware; &#39;&#39;&#39;</p><h2 id="结论" tabindex="-1">结论 <a class="header-anchor" href="#结论" aria-label="Permalink to &quot;结论&quot;">​</a></h2><p>正确的错误处理包括：</p><ul><li>结构化错误类</li><li>重试逻辑</li><li>详细日志记录</li><li>用户友好消息</li><li>监控和警报</li></ul><p>这些示例将帮助您为加密货币支付网关创建强大的错误处理系统。</p>`,44)]))}const h=r(s,[["render",o]]);export{u as __pageData,h as default};
