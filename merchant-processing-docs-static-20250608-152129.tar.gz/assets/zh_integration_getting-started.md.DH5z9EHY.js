import{_ as t,c as a,o as r,a0 as n}from"./chunks/framework.DCEeW4XT.js";const h=JSON.parse('{"title":"集成指南","description":"","frontmatter":{},"headers":[],"relativePath":"zh/integration/getting-started.md","filePath":"zh/integration/getting-started.md"}'),o={name:"zh/integration/getting-started.md"};function i(s,e,d,l,p,c){return r(),a("div",null,e[0]||(e[0]=[n(`<h1 id="集成指南" tabindex="-1">集成指南 <a class="header-anchor" href="#集成指南" aria-label="Permalink to &quot;集成指南&quot;">​</a></h1><p>本指南将帮助您将 Crypton Studio 支付网关集成到您的应用程序中。</p><h2 id="集成流程概览" tabindex="-1">集成流程概览 <a class="header-anchor" href="#集成流程概览" aria-label="Permalink to &quot;集成流程概览&quot;">​</a></h2><p>&#39;&#39;&#39;mermaid graph TD A[注册商户账户] --&gt; B[获取 API 密钥] B --&gt; C[选择集成方式] C --&gt; D[SDK 集成] C --&gt; E[直接 API 调用] D --&gt; F[测试集成] E --&gt; F F --&gt; G[配置 Webhook] G --&gt; H[上线部署] &#39;&#39;&#39;</p><h2 id="第一步-环境准备" tabindex="-1">第一步：环境准备 <a class="header-anchor" href="#第一步-环境准备" aria-label="Permalink to &quot;第一步：环境准备&quot;">​</a></h2><h3 id="_1-注册账户" tabindex="-1">1. 注册账户 <a class="header-anchor" href="#_1-注册账户" aria-label="Permalink to &quot;1. 注册账户&quot;">​</a></h3><ul><li>访问 <a href="https://dashboard.crypton.studio" target="_blank" rel="noreferrer">Crypton Studio 控制台</a></li><li>注册商户账户</li><li>完成身份验证</li></ul><h3 id="_2-获取-api-密钥" tabindex="-1">2. 获取 API 密钥 <a class="header-anchor" href="#_2-获取-api-密钥" aria-label="Permalink to &quot;2. 获取 API 密钥&quot;">​</a></h3><ul><li>在控制台生成测试环境密钥</li><li>保存 Client Key 和 Admin Key</li><li>配置 IP 白名单（推荐）</li></ul><h3 id="_3-选择开发环境" tabindex="-1">3. 选择开发环境 <a class="header-anchor" href="#_3-选择开发环境" aria-label="Permalink to &quot;3. 选择开发环境&quot;">​</a></h3><ul><li><strong>测试环境</strong>: &#39;<a href="https://api-sandbox.crypton.studio" target="_blank" rel="noreferrer">https://api-sandbox.crypton.studio</a>&#39;</li><li><strong>生产环境</strong>: &#39;<a href="https://api.crypton.studio" target="_blank" rel="noreferrer">https://api.crypton.studio</a>&#39;</li></ul><h2 id="第二步-选择集成方式" tabindex="-1">第二步：选择集成方式 <a class="header-anchor" href="#第二步-选择集成方式" aria-label="Permalink to &quot;第二步：选择集成方式&quot;">​</a></h2><h3 id="方式一-使用-sdk-推荐" tabindex="-1">方式一：使用 SDK（推荐） <a class="header-anchor" href="#方式一-使用-sdk-推荐" aria-label="Permalink to &quot;方式一：使用 SDK（推荐）&quot;">​</a></h3><p>我们提供多种语言的官方 SDK：</p><div class="vp-code-group vp-adaptive-theme"><div class="tabs"></div><div class="blocks"><p>&#39;&#39;&#39;bash [Node.js] npm install @crypton/payment-sdk &#39;&#39;&#39;</p><p>&#39;&#39;&#39;bash [Python] pip install crypton-payment-sdk &#39;&#39;&#39;</p><p>&#39;&#39;&#39;bash [Go] go get github.com/crypton-studio/payment-sdk-go &#39;&#39;&#39;</p><p>&#39;&#39;&#39;bash [PHP] composer require crypton/payment-sdk &#39;&#39;&#39;</p></div></div><h3 id="方式二-直接-api-调用" tabindex="-1">方式二：直接 API 调用 <a class="header-anchor" href="#方式二-直接-api-调用" aria-label="Permalink to &quot;方式二：直接 API 调用&quot;">​</a></h3><p>如果您的语言没有官方 SDK，可以直接调用 REST API。</p><h2 id="第三步-基础集成" tabindex="-1">第三步：基础集成 <a class="header-anchor" href="#第三步-基础集成" aria-label="Permalink to &quot;第三步：基础集成&quot;">​</a></h2><h3 id="javascript-typescript-示例" tabindex="-1">JavaScript/TypeScript 示例 <a class="header-anchor" href="#javascript-typescript-示例" aria-label="Permalink to &quot;JavaScript/TypeScript 示例&quot;">​</a></h3><p>&#39;&#39;&#39;javascript import { CryptonClient } from &#39;@crypton/payment-sdk&#39;</p><p>// 初始化客户端 const client = new CryptonClient({ apiKey: &#39;ck_test_your_key_here&#39;, environment: &#39;sandbox&#39; })</p><p>// 创建支付地址 async function createPaymentAddress(amount, currency) { try { const address = await client.addresses.create({ network: &#39;ethereum&#39;, coin: currency, label: &#39;Payment for order &#39; + orderId + &#39;&#39;, metadata: { orderId: orderId, amount: amount, currency: currency } })</p><pre><code>return {
  address: address.address,
  qrCode: address.qrCode,
  id: address.id
}
</code></pre><p>} catch (error) { console.error(&#39;创建地址失败:&#39;, error) throw error } }</p><p>// 检查支付状态 async function checkPaymentStatus(addressId) { try { const transactions = await client.addresses.getTransactions(addressId)</p><pre><code>for (const tx of transactions) {
  if (tx.status === &#39;confirmed&#39;) {
    return {
      status: &#39;paid&#39;,
      amount: tx.amount,
      hash: tx.hash,
      confirmations: tx.confirmations
    }
  }
}

return { status: &#39;pending&#39; }
</code></pre><p>} catch (error) { console.error(&#39;检查支付状态失败:&#39;, error) throw error } } &#39;&#39;&#39;</p><h3 id="python-示例" tabindex="-1">Python 示例 <a class="header-anchor" href="#python-示例" aria-label="Permalink to &quot;Python 示例&quot;">​</a></h3><p>&#39;&#39;&#39;python from crypton_sdk import CryptonClient import asyncio</p><h1 id="初始化客户端" tabindex="-1">初始化客户端 <a class="header-anchor" href="#初始化客户端" aria-label="Permalink to &quot;初始化客户端&quot;">​</a></h1><p>client = CryptonClient( api_key=&#39;ck_test_your_key_here&#39;, environment=&#39;sandbox&#39; )</p><p>async def create_payment_address(amount, currency, order_id): &quot;&quot;&quot;创建支付地址&quot;&quot;&quot; try: address = await client.addresses.create({ &#39;network&#39;: &#39;ethereum&#39;, &#39;coin&#39;: currency, &#39;label&#39;: f&#39;Payment for order {order_id}&#39;, &#39;metadata&#39;: { &#39;order_id&#39;: order_id, &#39;amount&#39;: amount, &#39;currency&#39;: currency } })</p><pre><code>    return {
        &#39;address&#39;: address.address,
        &#39;qr_code&#39;: address.qr_code,
        &#39;id&#39;: address.id
    }
except Exception as error:
    print(f&#39;创建地址失败: {error}&#39;)
    raise
</code></pre><p>async def check_payment_status(address_id): &quot;&quot;&quot;检查支付状态&quot;&quot;&quot; try: transactions = await client.addresses.get_transactions(address_id)</p><pre><code>    for tx in transactions:
        if tx.status == &#39;confirmed&#39;:
            return {
                &#39;status&#39;: &#39;paid&#39;,
                &#39;amount&#39;: tx.amount,
                &#39;hash&#39;: tx.hash,
                &#39;confirmations&#39;: tx.confirmations
            }
    
    return {&#39;status&#39;: &#39;pending&#39;}
except Exception as error:
    print(f&#39;检查支付状态失败: {error}&#39;)
    raise
</code></pre><p>&#39;&#39;&#39;</p><h3 id="go-示例" tabindex="-1">Go 示例 <a class="header-anchor" href="#go-示例" aria-label="Permalink to &quot;Go 示例&quot;">​</a></h3><p>&#39;&#39;&#39;go package main</p><p>import ( &quot;context&quot; &quot;fmt&quot; &quot;log&quot;</p><pre><code>&quot;github.com/crypton-studio/payment-sdk-go&quot;
</code></pre><p>)</p><p>func main() { // 初始化客户端 client := crypton.NewClient(&amp;crypton.Config{ APIKey: &quot;ck_test_your_key_here&quot;, Environment: &quot;sandbox&quot;, })</p><pre><code>// 创建支付地址
address, err := createPaymentAddress(client, &quot;100.00&quot;, &quot;USDT&quot;, &quot;order_123&quot;)
if err != nil {
    log.Fatal(err)
}

fmt.Printf(&quot;支付地址: %s\\n&quot;, address.Address)
fmt.Printf(&quot;二维码: %s\\n&quot;, address.QRCode)
</code></pre><p>}</p><p>func createPaymentAddress(client *crypton.Client, amount, currency, orderID string) (*crypton.Address, error) { ctx := context.Background()</p><pre><code>req := &amp;crypton.CreateAddressRequest{
    Network: &quot;ethereum&quot;,
    Coin:    currency,
    Label:   fmt.Sprintf(&quot;Payment for order %s&quot;, orderID),
    Metadata: map[string]interface{}{
        &quot;order_id&quot;: orderID,
        &quot;amount&quot;:   amount,
        &quot;currency&quot;: currency,
    },
}

return client.Addresses.Create(ctx, req)
</code></pre><p>}</p><p>func checkPaymentStatus(client *crypton.Client, addressID string) (*PaymentStatus, error) { ctx := context.Background()</p><pre><code>transactions, err := client.Addresses.GetTransactions(ctx, addressID)
if err != nil {
    return nil, err
}

for _, tx := range transactions {
    if tx.Status == &quot;confirmed&quot; {
        return &amp;PaymentStatus{
            Status:        &quot;paid&quot;,
            Amount:        tx.Amount,
            Hash:          tx.Hash,
            Confirmations: tx.Confirmations,
        }, nil
    }
}

return &amp;PaymentStatus{Status: &quot;pending&quot;}, nil
</code></pre><p>}</p><p>type PaymentStatus struct { Status string &#39;json:&quot;status&quot;&#39; Amount string &#39;json:&quot;amount,omitempty&quot;&#39; Hash string &#39;json:&quot;hash,omitempty&quot;&#39; Confirmations int &#39;json:&quot;confirmations,omitempty&quot;&#39; } &#39;&#39;&#39;</p><h2 id="第四步-配置-webhook" tabindex="-1">第四步：配置 Webhook <a class="header-anchor" href="#第四步-配置-webhook" aria-label="Permalink to &quot;第四步：配置 Webhook&quot;">​</a></h2><p>Webhook 允许您实时接收支付状态更新：</p><h3 id="_1-创建-webhook-端点" tabindex="-1">1. 创建 Webhook 端点 <a class="header-anchor" href="#_1-创建-webhook-端点" aria-label="Permalink to &quot;1. 创建 Webhook 端点&quot;">​</a></h3><div class="vp-code-group vp-adaptive-theme"><div class="tabs"></div><div class="blocks"><p>&#39;&#39;&#39;javascript [Express.js] const express = require(&#39;express&#39;) const crypto = require(&#39;crypto&#39;)</p><p>const app = express() app.use(express.json())</p><p>app.post(&#39;/webhook&#39;, (req, res) =&gt; { // 验证签名 const signature = req.headers[&#39;x-crypton-signature&#39;] const payload = JSON.stringify(req.body)</p><p>if (!verifySignature(payload, signature, process.env.WEBHOOK_SECRET)) { return res.status(401).send(&#39;Invalid signature&#39;) }</p><p>// 处理事件 const { event, data } = req.body</p><p>switch (event) { case &#39;transaction.confirmed&#39;: handlePaymentConfirmed(data) break case &#39;transaction.failed&#39;: handlePaymentFailed(data) break default: console.log(&#39;未知事件:&#39;, event) }</p><p>res.status(200).send(&#39;OK&#39;) })</p><p>function verifySignature(payload, signature, secret) { const expectedSignature = crypto .createHmac(&#39;sha256&#39;, secret) .update(payload) .digest(&#39;hex&#39;)</p><p>return &#39;sha256=&#39; + expectedSignature + &#39;&#39; === signature }</p><p>function handlePaymentConfirmed(data) { console.log(&#39;支付确认:&#39;, data) // 更新订单状态 // 发送确认邮件 // 处理业务逻辑 }</p><p>app.listen(3000) &#39;&#39;&#39;</p><p>&#39;&#39;&#39;python [Flask] from flask import Flask, request, jsonify import hmac import hashlib import json</p><p>app = Flask(<strong>name</strong>)</p><p>@app.route(&#39;/webhook&#39;, methods=[&#39;POST&#39;]) def webhook(): # 验证签名 signature = request.headers.get(&#39;X-Crypton-Signature&#39;) payload = request.get_data()</p><pre><code>if not verify_signature(payload, signature, WEBHOOK_SECRET):
    return jsonify({&#39;error&#39;: &#39;Invalid signature&#39;}), 401

# 处理事件
data = request.get_json()
event = data[&#39;event&#39;]
event_data = data[&#39;data&#39;]

if event == &#39;transaction.confirmed&#39;:
    handle_payment_confirmed(event_data)
elif event == &#39;transaction.failed&#39;:
    handle_payment_failed(event_data)
else:
    print(f&#39;未知事件: {event}&#39;)

return jsonify({&#39;status&#39;: &#39;ok&#39;})
</code></pre><p>def verify_signature(payload, signature, secret): expected_signature = hmac.new( secret.encode(&#39;utf-8&#39;), payload, hashlib.sha256 ).hexdigest()</p><pre><code>return f&#39;sha256={expected_signature}&#39; == signature
</code></pre><p>def handle_payment_confirmed(data): print(f&#39;支付确认: {data}&#39;) # 更新订单状态 # 发送确认邮件 # 处理业务逻辑</p><p>if <strong>name</strong> == &#39;<strong>main</strong>&#39;: app.run(port=3000) &#39;&#39;&#39;</p></div></div><h3 id="_2-注册-webhook" tabindex="-1">2. 注册 Webhook <a class="header-anchor" href="#_2-注册-webhook" aria-label="Permalink to &quot;2. 注册 Webhook&quot;">​</a></h3><p>&#39;&#39;&#39;bash curl -X POST &quot;<a href="https://api-sandbox.crypton.studio/v1/webhooks" target="_blank" rel="noreferrer">https://api-sandbox.crypton.studio/v1/webhooks</a>&quot; <br> -H &quot;X-Api-Key: ak_test_your_admin_key&quot; <br> -H &quot;Content-Type: application/json&quot; <br> -d &#39;{ &quot;url&quot;: &quot;<a href="https://your-domain.com/webhook" target="_blank" rel="noreferrer">https://your-domain.com/webhook</a>&quot;, &quot;events&quot;: [ &quot;transaction.confirmed&quot;, &quot;transaction.failed&quot;, &quot;withdrawal.completed&quot; ] }&#39; &#39;&#39;&#39;</p><h2 id="第五步-错误处理" tabindex="-1">第五步：错误处理 <a class="header-anchor" href="#第五步-错误处理" aria-label="Permalink to &quot;第五步：错误处理&quot;">​</a></h2><h3 id="常见错误处理" tabindex="-1">常见错误处理 <a class="header-anchor" href="#常见错误处理" aria-label="Permalink to &quot;常见错误处理&quot;">​</a></h3><p>&#39;&#39;&#39;javascript async function handleApiCall(apiCall) { try { return await apiCall() } catch (error) { switch (error.code) { case &#39;INSUFFICIENT_BALANCE&#39;: // 余额不足 throw new Error(&#39;账户余额不足，请充值后重试&#39;)</p><pre><code>  case &#39;INVALID_ADDRESS&#39;:
    // 地址无效
    throw new Error(&#39;提现地址格式不正确&#39;)
  
  case &#39;NETWORK_CONGESTION&#39;:
    // 网络拥堵
    throw new Error(&#39;网络繁忙，请稍后重试&#39;)
  
  case &#39;RATE_LIMIT_EXCEEDED&#39;:
    // 频率限制
    await sleep(60000) // 等待 1 分钟
    return handleApiCall(apiCall) // 重试
  
  default:
    console.error(&#39;API 调用失败:&#39;, error)
    throw error
}
</code></pre><p>} }</p><p>function sleep(ms) { return new Promise(resolve =&gt; setTimeout(resolve, ms)) } &#39;&#39;&#39;</p><h3 id="重试机制" tabindex="-1">重试机制 <a class="header-anchor" href="#重试机制" aria-label="Permalink to &quot;重试机制&quot;">​</a></h3><p>&#39;&#39;&#39;javascript async function retryApiCall(apiCall, maxRetries = 3, delay = 1000) { for (let i = 0; i &lt; maxRetries; i++) { try { return await apiCall() } catch (error) { if (i === maxRetries - 1) throw error</p><pre><code>  // 指数退避
  await sleep(delay * Math.pow(2, i))
}
</code></pre><p>} } &#39;&#39;&#39;</p><h2 id="第六步-测试" tabindex="-1">第六步：测试 <a class="header-anchor" href="#第六步-测试" aria-label="Permalink to &quot;第六步：测试&quot;">​</a></h2><h3 id="单元测试示例" tabindex="-1">单元测试示例 <a class="header-anchor" href="#单元测试示例" aria-label="Permalink to &quot;单元测试示例&quot;">​</a></h3><p>&#39;&#39;&#39;javascript const { CryptonClient } = require(&#39;@crypton/payment-sdk&#39;)</p><p>describe(&#39;Crypton Payment Integration&#39;, () =&gt; { let client</p><p>beforeEach(() =&gt; { client = new CryptonClient({ apiKey: &#39;ck_test_mock_key&#39;, environment: &#39;sandbox&#39; }) })</p><p>test(&#39;should create payment address&#39;, async () =&gt; { const address = await client.addresses.create({ network: &#39;ethereum&#39;, coin: &#39;USDT&#39;, label: &#39;Test payment&#39; })</p><pre><code>expect(address).toHaveProperty(&#39;address&#39;)
expect(address).toHaveProperty(&#39;qrCode&#39;)
expect(address.network).toBe(&#39;ethereum&#39;)
</code></pre><p>})</p><p>test(&#39;should handle payment confirmation&#39;, async () =&gt; { const mockTransaction = { status: &#39;confirmed&#39;, amount: &#39;100.000000&#39;, hash: &#39;0x123...&#39; }</p><pre><code>const result = await handlePaymentConfirmed(mockTransaction)
expect(result.status).toBe(&#39;processed&#39;)
</code></pre><p>}) }) &#39;&#39;&#39;</p><h2 id="第七步-上线部署" tabindex="-1">第七步：上线部署 <a class="header-anchor" href="#第七步-上线部署" aria-label="Permalink to &quot;第七步：上线部署&quot;">​</a></h2><h3 id="生产环境检查清单" tabindex="-1">生产环境检查清单 <a class="header-anchor" href="#生产环境检查清单" aria-label="Permalink to &quot;生产环境检查清单&quot;">​</a></h3><ul><li>[ ] 使用生产环境 API 密钥</li><li>[ ] 配置 HTTPS</li><li>[ ] 设置 IP 白名单</li><li>[ ] 配置监控和日志</li><li>[ ] 测试 Webhook 端点</li><li>[ ] 设置错误告警</li><li>[ ] 准备客服支持</li></ul><h3 id="环境变量配置" tabindex="-1">环境变量配置 <a class="header-anchor" href="#环境变量配置" aria-label="Permalink to &quot;环境变量配置&quot;">​</a></h3><p>&#39;&#39;&#39;bash</p><h1 id="生产环境配置" tabindex="-1">生产环境配置 <a class="header-anchor" href="#生产环境配置" aria-label="Permalink to &quot;生产环境配置&quot;">​</a></h1><p>CRYPTON_API_KEY=ck_live_your_production_key CRYPTON_ADMIN_KEY=ak_live_your_admin_key CRYPTON_ENVIRONMENT=production WEBHOOK_SECRET=your_webhook_secret &#39;&#39;&#39;</p><h2 id="最佳实践" tabindex="-1">最佳实践 <a class="header-anchor" href="#最佳实践" aria-label="Permalink to &quot;最佳实践&quot;">​</a></h2><h3 id="_1-安全性" tabindex="-1">1. 安全性 <a class="header-anchor" href="#_1-安全性" aria-label="Permalink to &quot;1. 安全性&quot;">​</a></h3><ul><li>使用 HTTPS</li><li>验证 Webhook 签名</li><li>定期轮换 API 密钥</li><li>实施 IP 白名单</li></ul><h3 id="_2-性能优化" tabindex="-1">2. 性能优化 <a class="header-anchor" href="#_2-性能优化" aria-label="Permalink to &quot;2. 性能优化&quot;">​</a></h3><ul><li>使用连接池</li><li>实施缓存策略</li><li>异步处理 Webhook</li><li>监控 API 调用频率</li></ul><h3 id="_3-错误处理" tabindex="-1">3. 错误处理 <a class="header-anchor" href="#_3-错误处理" aria-label="Permalink to &quot;3. 错误处理&quot;">​</a></h3><ul><li>实施重试机制</li><li>记录详细日志</li><li>设置告警通知</li><li>准备降级方案</li></ul><h3 id="_4-监控" tabindex="-1">4. 监控 <a class="header-anchor" href="#_4-监控" aria-label="Permalink to &quot;4. 监控&quot;">​</a></h3><ul><li>监控支付成功率</li><li>跟踪 API 响应时间</li><li>监控余额变化</li><li>设置异常告警</li></ul><h2 id="技术支持" tabindex="-1">技术支持 <a class="header-anchor" href="#技术支持" aria-label="Permalink to &quot;技术支持&quot;">​</a></h2><p>如果您在集成过程中遇到问题：</p><ul><li><strong>文档</strong>: 查看详细的 API 文档</li><li><strong>示例</strong>: 参考 GitHub 上的示例项目</li><li><strong>支持</strong>: 联系技术支持团队</li><li><strong>社区</strong>: 加入开发者社区</li></ul><hr><p>准备好开始集成了吗？查看 <a href="/Merchant-Processing-docs/zh/api/overview.html">API 文档</a> 获取详细信息。</p>`,99)]))}const m=t(o,[["render",i]]);export{h as __pageData,m as default};
