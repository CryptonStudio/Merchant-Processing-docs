import{_ as e,c as a,o as n,a0 as r}from"./chunks/framework.DCEeW4XT.js";const m=JSON.parse('{"title":"基本用法示例","description":"","frontmatter":{},"headers":[],"relativePath":"zh/examples/basic-usage.md","filePath":"zh/examples/basic-usage.md"}'),o={name:"zh/examples/basic-usage.md"};function s(p,t,d,i,u,c){return n(),a("div",null,t[0]||(t[0]=[r(`<h1 id="基本用法示例" tabindex="-1">基本用法示例 <a class="header-anchor" href="#基本用法示例" aria-label="Permalink to &quot;基本用法示例&quot;">​</a></h1><p>本页面提供了使用 Crypton Studio 支付网关的基本代码示例。</p><h2 id="完整的支付流程示例" tabindex="-1">完整的支付流程示例 <a class="header-anchor" href="#完整的支付流程示例" aria-label="Permalink to &quot;完整的支付流程示例&quot;">​</a></h2><h3 id="javascript-node-js" tabindex="-1">JavaScript/Node.js <a class="header-anchor" href="#javascript-node-js" aria-label="Permalink to &quot;JavaScript/Node.js&quot;">​</a></h3><p>&#39;&#39;&#39;javascript const { CryptonClient } = require(&#39;@crypton/payment-sdk&#39;) const express = require(&#39;express&#39;) const crypto = require(&#39;crypto&#39;)</p><p>// 初始化客户端 const client = new CryptonClient({ apiKey: process.env.CRYPTON_API_KEY, environment: process.env.NODE_ENV === &#39;production&#39; ? &#39;production&#39; : &#39;sandbox&#39; })</p><p>const app = express() app.use(express.json())</p><p>// 创建支付订单 app.post(&#39;/create-payment&#39;, async (req, res) =&gt; { try { const { amount, currency, orderId } = req.body</p><pre><code>// 创建支付地址
const address = await client.addresses.create({
  network: &#39;ethereum&#39;,
  coin: currency,
  label: &#39;订单支付 - &#39; + orderId + &#39;&#39;,
  metadata: {
    orderId,
    amount,
    currency,
    createdAt: new Date().toISOString()
  }
})

res.json({
  success: true,
  data: {
    paymentAddress: address.address,
    qrCode: address.qrCode,
    addressId: address.id,
    amount,
    currency,
    orderId
  }
})
</code></pre><p>} catch (error) { console.error(&#39;创建支付失败:&#39;, error) res.status(500).json({ success: false, error: error.message }) } })</p><p>// 检查支付状态 app.get(&#39;/payment-status/:addressId&#39;, async (req, res) =&gt; { try { const { addressId } = req.params</p><pre><code>const transactions = await client.addresses.getTransactions(addressId)

let status = &#39;pending&#39;
let transaction = null

for (const tx of transactions) {
  if (tx.status === &#39;confirmed&#39;) {
    status = &#39;completed&#39;
    transaction = tx
    break
  } else if (tx.status === &#39;pending&#39;) {
    status = &#39;pending&#39;
    transaction = tx
  }
}

res.json({
  success: true,
  data: {
    status,
    transaction
  }
})
</code></pre><p>} catch (error) { console.error(&#39;检查支付状态失败:&#39;, error) res.status(500).json({ success: false, error: error.message }) } })</p><p>// Webhook 处理 app.post(&#39;/webhook&#39;, (req, res) =&gt; { try { // 验证签名 const signature = req.headers[&#39;x-crypton-signature&#39;] const payload = JSON.stringify(req.body)</p><pre><code>if (!verifyWebhookSignature(payload, signature)) {
  return res.status(401).send(&#39;Invalid signature&#39;)
}

const { event, data } = req.body

switch (event) {
  case &#39;transaction.confirmed&#39;:
    handlePaymentConfirmed(data)
    break
  case &#39;transaction.failed&#39;:
    handlePaymentFailed(data)
    break
  default:
    console.log(&#39;未处理的事件:&#39;, event)
}

res.status(200).send(&#39;OK&#39;)
</code></pre><p>} catch (error) { console.error(&#39;Webhook 处理失败:&#39;, error) res.status(500).send(&#39;Internal Server Error&#39;) } })</p><p>function verifyWebhookSignature(payload, signature) { const secret = process.env.WEBHOOK_SECRET const expectedSignature = crypto .createHmac(&#39;sha256&#39;, secret) .update(payload) .digest(&#39;hex&#39;)</p><p>return &#39;sha256=&#39; + expectedSignature + &#39;&#39; === signature }</p><p>function handlePaymentConfirmed(data) { console.log(&#39;支付确认:&#39;, data)</p><p>// 更新数据库中的订单状态 // updateOrderStatus(data.metadata.orderId, &#39;paid&#39;)</p><p>// 发送确认邮件 // sendConfirmationEmail(data.metadata.orderId)</p><p>// 处理其他业务逻辑 }</p><p>function handlePaymentFailed(data) { console.log(&#39;支付失败:&#39;, data)</p><p>// 更新订单状态为失败 // updateOrderStatus(data.metadata.orderId, &#39;failed&#39;)</p><p>// 通知用户 // notifyPaymentFailed(data.metadata.orderId) }</p><p>app.listen(3000, () =&gt; { console.log(&#39;服务器运行在端口 3000&#39;) }) &#39;&#39;&#39;</p><h3 id="python-flask" tabindex="-1">Python/Flask <a class="header-anchor" href="#python-flask" aria-label="Permalink to &quot;Python/Flask&quot;">​</a></h3><p>&#39;&#39;&#39;python import os import hmac import hashlib import json from flask import Flask, request, jsonify from crypton_sdk import CryptonClient</p><h1 id="初始化客户端" tabindex="-1">初始化客户端 <a class="header-anchor" href="#初始化客户端" aria-label="Permalink to &quot;初始化客户端&quot;">​</a></h1><p>client = CryptonClient( api_key=os.getenv(&#39;CRYPTON_API_KEY&#39;), environment=&#39;production&#39; if os.getenv(&#39;FLASK_ENV&#39;) == &#39;production&#39; else &#39;sandbox&#39; )</p><p>app = Flask(<strong>name</strong>)</p><p>@app.route(&#39;/create-payment&#39;, methods=[&#39;POST&#39;]) def create_payment(): try: data = request.get_json() amount = data[&#39;amount&#39;] currency = data[&#39;currency&#39;] order_id = data[&#39;orderId&#39;]</p><pre><code>    # 创建支付地址
    address = client.addresses.create({
        &#39;network&#39;: &#39;ethereum&#39;,
        &#39;coin&#39;: currency,
        &#39;label&#39;: f&#39;订单支付 - {order_id}&#39;,
        &#39;metadata&#39;: {
            &#39;order_id&#39;: order_id,
            &#39;amount&#39;: amount,
            &#39;currency&#39;: currency,
            &#39;created_at&#39;: datetime.utcnow().isoformat()
        }
    })
    
    return jsonify({
        &#39;success&#39;: True,
        &#39;data&#39;: {
            &#39;payment_address&#39;: address.address,
            &#39;qr_code&#39;: address.qr_code,
            &#39;address_id&#39;: address.id,
            &#39;amount&#39;: amount,
            &#39;currency&#39;: currency,
            &#39;order_id&#39;: order_id
        }
    })
except Exception as error:
    print(f&#39;创建支付失败: {error}&#39;)
    return jsonify({
        &#39;success&#39;: False,
        &#39;error&#39;: str(error)
    }), 500
</code></pre><p>@app.route(&#39;/payment-status/&lt;address_id&gt;&#39;) def payment_status(address_id): try: transactions = client.addresses.get_transactions(address_id)</p><pre><code>    status = &#39;pending&#39;
    transaction = None
    
    for tx in transactions:
        if tx.status == &#39;confirmed&#39;:
            status = &#39;completed&#39;
            transaction = tx.__dict__
            break
        elif tx.status == &#39;pending&#39;:
            status = &#39;pending&#39;
            transaction = tx.__dict__
    
    return jsonify({
        &#39;success&#39;: True,
        &#39;data&#39;: {
            &#39;status&#39;: status,
            &#39;transaction&#39;: transaction
        }
    })
except Exception as error:
    print(f&#39;检查支付状态失败: {error}&#39;)
    return jsonify({
        &#39;success&#39;: False,
        &#39;error&#39;: str(error)
    }), 500
</code></pre><p>@app.route(&#39;/webhook&#39;, methods=[&#39;POST&#39;]) def webhook(): try: # 验证签名 signature = request.headers.get(&#39;X-Crypton-Signature&#39;) payload = request.get_data()</p><pre><code>    if not verify_webhook_signature(payload, signature):
        return &#39;Invalid signature&#39;, 401
    
    data = request.get_json()
    event = data[&#39;event&#39;]
    event_data = data[&#39;data&#39;]
    
    if event == &#39;transaction.confirmed&#39;:
        handle_payment_confirmed(event_data)
    elif event == &#39;transaction.failed&#39;:
        handle_payment_failed(event_data)
    else:
        print(f&#39;未处理的事件: {event}&#39;)
    
    return &#39;OK&#39;, 200
except Exception as error:
    print(f&#39;Webhook 处理失败: {error}&#39;)
    return &#39;Internal Server Error&#39;, 500
</code></pre><p>def verify_webhook_signature(payload, signature): secret = os.getenv(&#39;WEBHOOK_SECRET&#39;).encode(&#39;utf-8&#39;) expected_signature = hmac.new( secret, payload, hashlib.sha256 ).hexdigest()</p><pre><code>return f&#39;sha256={expected_signature}&#39; == signature
</code></pre><p>def handle_payment_confirmed(data): print(f&#39;支付确认: {data}&#39;)</p><pre><code># 更新数据库中的订单状态
# update_order_status(data[&#39;metadata&#39;][&#39;order_id&#39;], &#39;paid&#39;)

# 发送确认邮件
# send_confirmation_email(data[&#39;metadata&#39;][&#39;order_id&#39;])
</code></pre><p>def handle_payment_failed(data): print(f&#39;支付失败: {data}&#39;)</p><pre><code># 更新订单状态为失败
# update_order_status(data[&#39;metadata&#39;][&#39;order_id&#39;], &#39;failed&#39;)
</code></pre><p>if <strong>name</strong> == &#39;<strong>main</strong>&#39;: app.run(debug=True, port=3000) &#39;&#39;&#39;</p><h3 id="go" tabindex="-1">Go <a class="header-anchor" href="#go" aria-label="Permalink to &quot;Go&quot;">​</a></h3><p>&#39;&#39;&#39;go package main</p><p>import ( &quot;context&quot; &quot;crypto/hmac&quot; &quot;crypto/sha256&quot; &quot;encoding/hex&quot; &quot;encoding/json&quot; &quot;fmt&quot; &quot;log&quot; &quot;net/http&quot; &quot;os&quot; &quot;time&quot;</p><pre><code>&quot;github.com/gin-gonic/gin&quot;
&quot;github.com/crypton-studio/payment-sdk-go&quot;
</code></pre><p>)</p><p>type PaymentRequest struct { Amount string &#39;json:&quot;amount&quot;&#39; Currency string &#39;json:&quot;currency&quot;&#39; OrderID string &#39;json:&quot;orderId&quot;&#39; }</p><p>type PaymentResponse struct { Success bool &#39;json:&quot;success&quot;&#39; Data interface{ + &#39; &#39;json:&quot;data,omitempty&quot;&#39; Error string &#39;json:&quot;error,omitempty&quot;&#39; }</p><p>type WebhookPayload struct { Event string &#39;json:&quot;event&quot;&#39; Data interface{ + &#39; &#39;json:&quot;data&quot;&#39; }</p><p>var client *crypton.Client</p><p>func main() { // 初始化客户端 environment := &quot;sandbox&quot; if os.Getenv(&quot;GIN_MODE&quot;) == &quot;release&quot; { environment = &quot;production&quot; }</p><pre><code>client = crypton.NewClient(&amp;crypton.Config{
    APIKey:      os.Getenv(&quot;CRYPTON_API_KEY&quot;),
    Environment: environment,
})

r := gin.Default()

r.POST(&quot;/create-payment&quot;, createPayment)
r.GET(&quot;/payment-status/:addressId&quot;, paymentStatus)
r.POST(&quot;/webhook&quot;, webhook)

r.Run(&quot;:3000&quot;)
</code></pre><p>}</p><p>func createPayment(c *gin.Context) { var req PaymentRequest if err := c.ShouldBindJSON(&amp;req); err != nil { c.JSON(http.StatusBadRequest, PaymentResponse{ Success: false, Error: err.Error(), }) return }</p><pre><code>ctx := context.Background()

// 创建支付地址
address, err := client.Addresses.Create(ctx, &amp;crypton.CreateAddressRequest{
    Network: &quot;ethereum&quot;,
    Coin:    req.Currency,
    Label:   fmt.Sprintf(&quot;订单支付 - %s&quot;, req.OrderID),
    Metadata: map[string]interface{}{
        &quot;order_id&quot;:   req.OrderID,
        &quot;amount&quot;:     req.Amount,
        &quot;currency&quot;:   req.Currency,
        &quot;created_at&quot;: time.Now().Format(time.RFC3339),
    },
})

if err != nil {
    log.Printf(&quot;创建支付失败: %v&quot;, err)
    c.JSON(http.StatusInternalServerError, PaymentResponse{
        Success: false,
        Error:   err.Error(),
    })
    return
}

c.JSON(http.StatusOK, PaymentResponse{
    Success: true,
    Data: map[string]interface{}{
        &quot;payment_address&quot;: address.Address,
        &quot;qr_code&quot;:        address.QRCode,
        &quot;address_id&quot;:     address.ID,
        &quot;amount&quot;:         req.Amount,
        &quot;currency&quot;:       req.Currency,
        &quot;order_id&quot;:       req.OrderID,
    },
})
</code></pre><p>}</p><p>func paymentStatus(c *gin.Context) { addressID := c.Param(&quot;addressId&quot;) ctx := context.Background()</p><pre><code>transactions, err := client.Addresses.GetTransactions(ctx, addressID)
if err != nil {
    log.Printf(&quot;检查支付状态失败: %v&quot;, err)
    c.JSON(http.StatusInternalServerError, PaymentResponse{
        Success: false,
        Error:   err.Error(),
    })
    return
}

status := &quot;pending&quot;
var transaction *crypton.Transaction

for _, tx := range transactions {
    if tx.Status == &quot;confirmed&quot; {
        status = &quot;completed&quot;
        transaction = tx
        break
    } else if tx.Status == &quot;pending&quot; {
        status = &quot;pending&quot;
        transaction = tx
    }
}

c.JSON(http.StatusOK, PaymentResponse{
    Success: true,
    Data: map[string]interface{}{
        &quot;status&quot;:      status,
        &quot;transaction&quot;: transaction,
    },
})
</code></pre><p>}</p><p>func webhook(c *gin.Context) { // 验证签名 signature := c.GetHeader(&quot;X-Crypton-Signature&quot;) body, err := c.GetRawData() if err != nil { c.String(http.StatusBadRequest, &quot;Invalid request body&quot;) return }</p><pre><code>if !verifyWebhookSignature(body, signature) {
    c.String(http.StatusUnauthorized, &quot;Invalid signature&quot;)
    return
}

var payload WebhookPayload
if err := json.Unmarshal(body, &amp;payload); err != nil {
    c.String(http.StatusBadRequest, &quot;Invalid JSON&quot;)
    return
}

switch payload.Event {
case &quot;transaction.confirmed&quot;:
    handlePaymentConfirmed(payload.Data)
case &quot;transaction.failed&quot;:
    handlePaymentFailed(payload.Data)
default:
    log.Printf(&quot;未处理的事件: %s&quot;, payload.Event)
}

c.String(http.StatusOK, &quot;OK&quot;)
</code></pre><p>}</p><p>func verifyWebhookSignature(payload []byte, signature string) bool { secret := os.Getenv(&quot;WEBHOOK_SECRET&quot;) mac := hmac.New(sha256.New, []byte(secret)) mac.Write(payload) expectedSignature := hex.EncodeToString(mac.Sum(nil))</p><pre><code>return fmt.Sprintf(&quot;sha256=%s&quot;, expectedSignature) == signature
</code></pre><p>}</p><p>func handlePaymentConfirmed(data interface{}) { log.Printf(&quot;支付确认: %+v&quot;, data)</p><pre><code>// 更新数据库中的订单状态
// updateOrderStatus(data.metadata.order_id, &quot;paid&quot;)

// 发送确认邮件
// sendConfirmationEmail(data.metadata.order_id)
</code></pre><p>}</p><p>func handlePaymentFailed(data interface{}) { log.Printf(&quot;支付失败: %+v&quot;, data)</p><pre><code>// 更新订单状态为失败
// updateOrderStatus(data.metadata.order_id, &quot;failed&quot;)
</code></pre><p>} &#39;&#39;&#39;</p><h2 id="前端集成示例" tabindex="-1">前端集成示例 <a class="header-anchor" href="#前端集成示例" aria-label="Permalink to &quot;前端集成示例&quot;">​</a></h2><h3 id="react-组件" tabindex="-1">React 组件 <a class="header-anchor" href="#react-组件" aria-label="Permalink to &quot;React 组件&quot;">​</a></h3><p>&#39;&#39;&#39;jsx import React, { useState, useEffect } from &#39;react&#39; import QRCode from &#39;qrcode.react&#39;</p><p>const PaymentComponent = ({ amount, currency, orderId }) =&gt; { const [paymentData, setPaymentData] = useState(null) const [paymentStatus, setPaymentStatus] = useState(&#39;pending&#39;) const [loading, setLoading] = useState(false) const [error, setError] = useState(null)</p><p>// 创建支付 const createPayment = async () =&gt; { setLoading(true) setError(null)</p><pre><code>try {
  const response = await fetch(&#39;/api/create-payment&#39;, {
    method: &#39;POST&#39;,
    headers: {
      &#39;Content-Type&#39;: &#39;application/json&#39;,
    },
    body: JSON.stringify({
      amount,
      currency,
      orderId
    })
  })
  
  const result = await response.json()
  
  if (result.success) {
    setPaymentData(result.data)
    startStatusPolling(result.data.addressId)
  } else {
    setError(result.error)
  }
} catch (err) {
  setError(&#39;创建支付失败&#39;)
} finally {
  setLoading(false)
}
</code></pre><p>}</p><p>// 轮询支付状态 const startStatusPolling = (addressId) =&gt; { const interval = setInterval(async () =&gt; { try { const response = await fetch(&#39;/api/payment-status/&#39; + addressId + &#39;&#39;) const result = await response.json()</p><pre><code>    if (result.success) {
      setPaymentStatus(result.data.status)
      
      if (result.data.status === &#39;completed&#39;) {
        clearInterval(interval)
        onPaymentCompleted(result.data.transaction)
      }
    }
  } catch (err) {
    console.error(&#39;检查支付状态失败:&#39;, err)
  }
}, 10000) // 每 10 秒检查一次

// 5 分钟后停止轮询
setTimeout(() =&gt; clearInterval(interval), 300000)
</code></pre><p>}</p><p>const onPaymentCompleted = (transaction) =&gt; { alert(&#39;支付成功！交易哈希: &#39; + transaction.hash + &#39;&#39;) }</p><p>const copyToClipboard = (text) =&gt; { navigator.clipboard.writeText(text) alert(&#39;地址已复制到剪贴板&#39;) }</p><p>useEffect(() =&gt; { createPayment() }, [])</p><p>if (loading) { return &lt;div className=&quot;loading&quot;&gt;创建支付中...&lt;/div&gt; }</p><p>if (error) { return ( &lt;div className=&quot;error&quot;&gt; &lt;p&gt;错误: {error}&lt;/p&gt; &lt;button onClick={createPayment}&gt;重试&lt;/button&gt; &lt;/div&gt; ) }</p><p>if (!paymentData) { return &lt;div&gt;加载中...&lt;/div&gt; }</p><p>return ( &lt;div className=&quot;payment-container&quot;&gt; &lt;h3&gt;支付信息&lt;/h3&gt;</p><pre><code>  &amp;lt;div className=&quot;payment-details&quot;&amp;gt;
    &amp;lt;p&amp;gt;&amp;lt;strong&amp;gt;订单号:&amp;lt;/strong&amp;gt; {orderId}&amp;lt;/p&amp;gt;
    &amp;lt;p&amp;gt;&amp;lt;strong&amp;gt;金额:&amp;lt;/strong&amp;gt; {amount} {currency}&amp;lt;/p&amp;gt;
    &amp;lt;p&amp;gt;&amp;lt;strong&amp;gt;状态:&amp;lt;/strong&amp;gt; 
      &amp;lt;span className={&#39;status &#39; + paymentStatus + &#39;&#39;}&amp;gt;
        {paymentStatus === &#39;pending&#39; ? &#39;等待支付&#39; : &#39;支付完成&#39;}
      &amp;lt;/span&amp;gt;
    &amp;lt;/p&amp;gt;
  &amp;lt;/div&amp;gt;

  &amp;lt;div className=&quot;qr-section&quot;&amp;gt;
    &amp;lt;h4&amp;gt;扫码支付&amp;lt;/h4&amp;gt;
    &lt;QRCode 
      value={paymentData.paymentAddress} 
      size={200}
      level=&quot;M&quot;
    /&gt;
  &amp;lt;/div&amp;gt;

  &amp;lt;div className=&quot;address-section&quot;&amp;gt;
    &amp;lt;h4&amp;gt;支付地址&amp;lt;/h4&amp;gt;
    &amp;lt;div className=&quot;address-input&quot;&amp;gt;
      &lt;input 
        type=&quot;text&quot; 
        value={paymentData.paymentAddress} 
        readOnly 
      /&gt;
      &amp;lt;button onClick={() =&amp;gt; copyToClipboard(paymentData.paymentAddress)}&gt;
        复制
      &amp;lt;/button&amp;gt;
    &amp;lt;/div&amp;gt;
  &amp;lt;/div&amp;gt;

  &amp;lt;div className=&quot;instructions&quot;&amp;gt;
    &amp;lt;h4&amp;gt;支付说明&amp;lt;/h4&amp;gt;
    &amp;lt;ul&amp;gt;
      &amp;lt;li&amp;gt;请向上述地址发送 &amp;lt;strong&amp;gt;{amount} {currency}&amp;lt;/strong&amp;gt;&amp;lt;/li&amp;gt;
      &amp;lt;li&amp;gt;支付确认通常需要 10-30 分钟&amp;lt;/li&amp;gt;
      &amp;lt;li&amp;gt;请勿发送其他币种到此地址&amp;lt;/li&amp;gt;
      &amp;lt;li&amp;gt;最小支付金额: 0.01 {currency}&amp;lt;/li&amp;gt;
    &amp;lt;/ul&amp;gt;
  &amp;lt;/div&amp;gt;

  {paymentStatus === &#39;pending&#39; &amp;&amp; (
    &amp;lt;div className=&quot;status-indicator&quot;&amp;gt;
      &amp;lt;div className=&quot;spinner&quot;&amp;gt;&amp;lt;/div&amp;gt;
      &amp;lt;p&amp;gt;等待支付确认...&amp;lt;/p&amp;gt;
    &amp;lt;/div&amp;gt;
  )}
&amp;lt;/div&amp;gt;
</code></pre><p>) }</p><p>export default PaymentComponent &#39;&#39;&#39;</p><h3 id="css-样式" tabindex="-1">CSS 样式 <a class="header-anchor" href="#css-样式" aria-label="Permalink to &quot;CSS 样式&quot;">​</a></h3><p>&#39;&#39;&#39;css .payment-container { max-width: 500px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px; font-family: Arial, sans-serif; }</p><p>.payment-details { background: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px; }</p><p>.status.pending { color: #ff9800; }</p><p>.status.completed { color: #4caf50; }</p><p>.qr-section { text-align: center; margin-bottom: 20px; }</p><p>.address-section { margin-bottom: 20px; }</p><p>.address-input { display: flex; gap: 10px; }</p><p>.address-input input { flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-family: monospace; }</p><p>.address-input button { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }</p><p>.instructions { background: #e3f2fd; padding: 15px; border-radius: 5px; margin-bottom: 20px; }</p><p>.instructions ul { margin: 10px 0; padding-left: 20px; }</p><p>.status-indicator { text-align: center; padding: 20px; }</p><p>.spinner { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto 10px; }</p><p>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</p><p>.loading, .error { text-align: center; padding: 40px; }</p><p>.error button { margin-top: 10px; padding: 10px 20px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; } &#39;&#39;&#39;</p><h2 id="环境配置" tabindex="-1">环境配置 <a class="header-anchor" href="#环境配置" aria-label="Permalink to &quot;环境配置&quot;">​</a></h2><h3 id="env-文件示例" tabindex="-1">.env 文件示例 <a class="header-anchor" href="#env-文件示例" aria-label="Permalink to &quot;.env 文件示例&quot;">​</a></h3><p>&#39;&#39;&#39;bash</p><h1 id="api-配置" tabindex="-1">API 配置 <a class="header-anchor" href="#api-配置" aria-label="Permalink to &quot;API 配置&quot;">​</a></h1><p>CRYPTON_API_KEY=ck_test_your_key_here CRYPTON_ADMIN_KEY=ak_test_your_admin_key_here CRYPTON_ENVIRONMENT=sandbox</p><h1 id="webhook-配置" tabindex="-1">Webhook 配置 <a class="header-anchor" href="#webhook-配置" aria-label="Permalink to &quot;Webhook 配置&quot;">​</a></h1><p>WEBHOOK_SECRET=your_webhook_secret_here</p><h1 id="数据库配置" tabindex="-1">数据库配置 <a class="header-anchor" href="#数据库配置" aria-label="Permalink to &quot;数据库配置&quot;">​</a></h1><p>DATABASE_URL=postgresql://user:password@localhost:5432/myapp</p><h1 id="应用配置" tabindex="-1">应用配置 <a class="header-anchor" href="#应用配置" aria-label="Permalink to &quot;应用配置&quot;">​</a></h1><p>NODE_ENV=development PORT=3000 &#39;&#39;&#39;</p><h3 id="docker-配置" tabindex="-1">Docker 配置 <a class="header-anchor" href="#docker-配置" aria-label="Permalink to &quot;Docker 配置&quot;">​</a></h3><p>&#39;&#39;&#39;dockerfile FROM node:16-alpine</p><p>WORKDIR /app</p><p>COPY package*.json ./ RUN npm ci --only=production</p><p>COPY . .</p><p>EXPOSE 3000</p><p>CMD [&quot;node&quot;, &quot;server.js&quot;] &#39;&#39;&#39;</p><h3 id="docker-compose-yml" tabindex="-1">docker-compose.yml <a class="header-anchor" href="#docker-compose-yml" aria-label="Permalink to &quot;docker-compose.yml&quot;">​</a></h3><p>&#39;&#39;&#39;yaml version: &#39;3.8&#39;</p><p>services: app: build: . ports: - &quot;3000:3000&quot; environment: - CRYPTON_API_KEY=\${CRYPTON_API_KEY} - CRYPTON_ADMIN_KEY=\${CRYPTON_ADMIN_KEY} - WEBHOOK_SECRET=\${WEBHOOK_SECRET} - DATABASE_URL=\${DATABASE_URL} depends_on: - postgres</p><p>postgres: image: postgres:13 environment: - POSTGRES_DB=myapp - POSTGRES_USER=user - POSTGRES_PASSWORD=password volumes: - postgres_data:/var/lib/postgresql/data</p><p>volumes: postgres_data: &#39;&#39;&#39;</p><h2 id="测试示例" tabindex="-1">测试示例 <a class="header-anchor" href="#测试示例" aria-label="Permalink to &quot;测试示例&quot;">​</a></h2><h3 id="jest-测试" tabindex="-1">Jest 测试 <a class="header-anchor" href="#jest-测试" aria-label="Permalink to &quot;Jest 测试&quot;">​</a></h3><p>&#39;&#39;&#39;javascript const request = require(&#39;supertest&#39;) const app = require(&#39;../app&#39;)</p><p>describe(&#39;Payment API&#39;, () =&gt; { test(&#39;POST /create-payment&#39;, async () =&gt; { const response = await request(app) .post(&#39;/create-payment&#39;) .send({ amount: &#39;100.00&#39;, currency: &#39;USDT&#39;, orderId: &#39;test-order-123&#39; }) .expect(200)</p><pre><code>expect(response.body.success).toBe(true)
expect(response.body.data).toHaveProperty(&#39;paymentAddress&#39;)
expect(response.body.data).toHaveProperty(&#39;qrCode&#39;)
</code></pre><p>})</p><p>test(&#39;GET /payment-status/:addressId&#39;, async () =&gt; { const addressId = &#39;test-address-id&#39;</p><pre><code>const response = await request(app)
  .get(&#39;/payment-status/&#39; + addressId + &#39;&#39;)
  .expect(200)

expect(response.body.success).toBe(true)
expect(response.body.data).toHaveProperty(&#39;status&#39;)
</code></pre><p>}) }) &#39;&#39;&#39;</p><p>这些示例展示了如何在不同的编程语言和框架中集成 Crypton Studio 支付网关。您可以根据自己的技术栈选择合适的示例作为起点。</p>`,144)]))}const g=e(o,[["render",s]]);export{m as __pageData,g as default};
